Custom Bedrock ingot textures.
Place PNG files into textures/items/
Then merge entries from item_texture.json.example into your item_texture.json
